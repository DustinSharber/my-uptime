# Uptime Agent for Linux (Python Source)

This is a Python source distribution of the Uptime Agent for Linux systems.

## Requirements
- Python 3.6 or newer
- pip (for installing dependencies)

## Installation & Usage

1. Extract this package to your desired location
2. Make the launcher executable (if not already):
   chmod +x uptime_agent

3. Run the agent:
   ./uptime_agent --monitor-id YOUR_MONITOR_ID --api-endpoint http://your-server:5000/api

## Manual Installation of Dependencies
If automatic installation fails:
pip install -r requirements.txt

## Direct Python Usage
You can also run the agent directly:
python3 agent_parameterized.py --monitor-id YOUR_MONITOR_ID --api-endpoint http://your-server:5000/api
